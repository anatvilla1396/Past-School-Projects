
function setup() {
  createCanvas(400, 400);
  rectMode(CENTER);}

function draw() {
  background("#ffe3bd");
 
  fill('#7bdae0')
  circle(11,59,150)
  circle(78,12,150)
  circle(150,0,100)
  circle(210,0,100)
  
  noStroke()
  fill("#f0dc99")
  rect(210,210,200,250)
  rect(83,160,50,75)
  fill(255)
  rect(200,200,200,250)
  fill(255,0,0)
  rect(200,90,200,45)
  
  
  fill(255)
  quad(75,175,55,75,200,10,300,50)
  fill("#ffe3bd")
  ellipse(250,35,150,75)
 
  fill("#c9c9c9")
  quad(100,180,100,160,190,111,209,112)
  
  fill("#a32a1f")
  quad(191,111,258,71,277,71,209,112)
  
  fill('#7bdae0')
  circle(230,0,100)
  
  fill("#d1ab43")
  textSize(35)
  textFont('Trebuchet MS')
  text('ONE',220,170)
  text('MORE',160,230)
  text('YEAR',110,290)
  textSize(20)
  text('tame impala',150,360)
 
  fill("#d1ab43")
  circle(45, 150, 6.3)
  circle(350, 270, 9.0)
  circle(90, 320, 7.5)
  circle(380, 80, 5.8)
  circle(280, 120, 8.4)
  circle(70, 35, 6.9)
  circle(200, 340, 5.2)
  circle(10, 270, 7.1)
  circle(160, 320, 9.6)
  circle(50, 50, 5.0)
  circle(320, 40, 7.3)
  circle(10, 390, 6.4)
  circle(300, 60, 8.1)
  circle(10, 200, 5.6)
  circle(90, 360, 8.7)
  circle(370, 170, 9.3)
  circle(50, 15, 6.5)
  circle(350, 250, 6.8)
  circle(30, 100, 7.9)
  circle(380, 350, 8.0)
  circle(70, 190, 5.7)
  circle(210, 70, 6.2)
  circle(340, 30, 9.2)
  circle(60, 280, 5.3)
  circle(20, 360, 7.8)
  circle(300, 10, 9.0)
  circle(230, 350, 6.7)
  circle(40, 180, 7.2)
  circle(10, 220, 8.5)
  circle(370, 90, 5.9)
  
  fill(255)
  arc(260,90,40,40,PI,PI+QUARTER_PI, CHORD)
  arc(270,90,40,40,PI,PI+QUARTER_PI, CHORD)
  arc(300,90,40,40,PI,PI+QUARTER_PI, CHORD)
  arc(310,90,40,40,PI,PI+QUARTER_PI, CHORD)
  
print(mouseX,mouseY)
}
