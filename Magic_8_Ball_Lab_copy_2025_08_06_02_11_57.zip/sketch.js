let responses = [
  "With certainty <3",
  "Without a doubt!",
  "You can rely on it, pretty much!",
  "Yes for sure twinski.",
  "As I see it for right now, yeah.",
  "Most likely, I think....",
  "Yes. Point blank.",
  "Yikes fren I don't know right now...",
  "You gon have to ask me again after my nap.",
  "Hey girlie...",
  "I lost my train of thought. Oops.",
  "Girl do you even really want it? Concentrate and ask again. Not playing w you...",
  "*Simon Cowell voice* It's gonna be a no for me...",
  "I fear not fren.",
  "I asked the grapevine, they said no chile.",
  "It's not looking too good girlie pop...",
  "Yeah probably for sure not going to happen."
];

let button;
let input;
let resultText = "";

function setup() {
  createCanvas(400, 400);

  input = createInput("Ask the 8-Ball");
  input.position(20, 20);

  button = createButton("Shake me");
  button.position(input.x, input.y + input.height + 10);
  button.mousePressed(shakeBall);
}

function draw() {
  background(30);
  fill(0);
  ellipse(200, 200, 300, 300);
  fill(20);
  ellipse(200, 200, 250, 250);
  fill(0, 0, 255);
  triangle(250, 250, 150, 250, 200, 100);
  fill(255);
  textAlign(CENTER, CENTER);
  text(resultText, 200, 200);
  text(input.value(), 200, 300);
  
  for (let i=0, i<100, )
}

function shakeBall() {
  resultText = responses[Math.floor(Math.random() * responses.length)]; //use responses.length
}