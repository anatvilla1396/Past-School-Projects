function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(210);
  fill(255)
  text("Hello! Start by clicking on the canvas.",20,20);
  text("Try pressing some buttons for a surprise. Will you survive?",20,30);
  
  if (keyIsPressed == true){
    square(200,200,100);
    fill(0)
    text("Good job, you pressed a key. Work it girl.",100,100);
  }

  //
  if (mouseIsPressed == true){
    circle(300,300,100);
    text("Good job, you pressed the mouse. The clicky sound is like ASMR!",20,50);
  }

  //
  if (keyIsPressed && key == '1'){
    triangle(130, 175, 158, 120, 186, 175);
    fill(0);
    text("You pressed 1. But are you really number one? Hmm...",100,350);
  }

  //
  if (key == 'c'){
    square(300,300,100);
    fill(0);
    text("You pressed c. Curious cats cautiously creep across crystal-clear corridors.",5,280);
    text("🐈",mouseX,mouseY);
  }

  //
  if(key == ' '){
    fill(0);
    square(0,0,400);
    fill(255);
    text("You pressed space. Does it feel empty in here?",90,90);
  }
    
//
  if (keyCode == UP_ARROW){
    fill(0);
    text("⬆️",250,300);
    text("You pressed up. Up, up and away!",90,350);
  }
  
  //
  if (keyCode == DOWN_ARROW){
    fill(0);
    text("⬇️",250,300);
    text("You pressed down. Baby are you down down down down down!",50,80)}
  
  //
  if (keyCode == ENTER){
    fill("#964B00");
    rect(190,120,100,200);
    fill(255);
    circle(270,200,20);
    text("You pressed enter, but you don't have a key to open the door. Trespasser!",3,350);
  }

  if (mouseX >= 300){
    fill(255,0,0);
    square(100,100,100);
    fill(255);
    text("STOP",130,150);
    fill(0);
    text("Now where do you think you're going? Get back here!", 100,300);
  }

  //
  if (mouseY <= 100){
    fill(255,0,0);
    square(100,100,100);
    fill(255);
    text("STOP",130,150);
    fill(0);
    text("Now where do you think you're going? Get back here!", 100,300);
    }
}