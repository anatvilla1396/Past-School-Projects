function setup() {
  createCanvas(400, 400);
}

function draw() {
  background("#B2AC88");
  
  fill(0,0,0)
  rect(150,190,100,90)
  
  fill("#e5c196")
  stroke(0,0,0)
  strokeWeight(1)
  circle(200,200, 100)
  
  //eyes left
  fill(0,0,0)
  arc(175,180,12,7,PI,0, CHORD)
  fill("#ffffff")
  strokeWeight(0)
  ellipse(175,195,20,30)
  strokeWeight(4)
  fill(0,0,0)
  circle(175,196,7)
  line(170,180,165,178)
  line(166,186,163,183)
  
  //eyes right
  fill(0,0,0)
  arc(222,180,10,5,PI,0, CHORD)
  fill("#ffffff")
  strokeWeight(0)
  ellipse(222,195,20,30)
  strokeWeight(3)
  fill(0,0,0)
  circle(222,195,7)
  line(227,180,237,178)
  line(232,186,237,184)
  
  //nose
  fill("#caa376")
  noStroke()
  circle(200,215,7)
  
  //lips
  fill("#cc8686")
  arc(195,230,12,8,PI,0, CHORD)
  arc(205,230,12,8,PI,0, CHORD)
  arc(200,231,12,8,0,PI, CHORD)
 
  //hair  
  noFill();
  stroke(0);
  strokeWeight(20);
  bezier(190, 150, 100, 180, 160, 250, 150, 300);
  noFill();
  stroke(0);
  strokeWeight(20);
  bezier(190, 150, 300, 180, 240, 250, 250, 300)
  fill(0,0,0)
  rect(150,260,100,40)
  
  //neck
  fill("#caa376")
  noStroke()
  rect(190,248,20,25)
  
  
  
}