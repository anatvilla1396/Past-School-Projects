function setup() {
  createCanvas(400, 400);
  print(mouseX,mouseY)
}

function draw() {
  background("#9dddfa");
  setCenter(width/2, height/2);
  stroke(255)
  fill("#ef9029")
  polarHexagon(0, 135+sin(frameCount/10)*40,0, 80)
  fill("#efc629")
  polarHexagon(0, 90 +sin(frameCount/10)*40,0, 80)
  fill("#fbf551")
  polarHexagon(0, 45 +sin(frameCount/10)*40,0, 80)
  fill("#fda8c5")
  noStroke()
  polarPentagons(7, 40, 100);
  fill(0,200,0)
  polarPentagon(0, 50, 0)
}

