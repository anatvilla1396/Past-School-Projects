let trackA, trackB, trackC, currentTrack;
let gui;
let volumeSlider, speedSlider, reverbToggle, switchButton;
let amplitude, reverb;

let lastReverbState = false;
let lastSwitchButtonState = false;

function preload() {
  trackA = loadSound("Another life (feat. Rema).mp3");
  trackB = loadSound("Tame Impala The Less I Know The Better (Isolated Vocal Track) (1).mp3");
  trackC = loadSound("GEE LEE, Riton and Kah-Lo - Coke & Rum (Fake ID Remix) - Official Video.mp3");
}

function setup() {
  function setup() {
  createCanvas(windowWidth, windowHeight);
  userStartAudio();

  amplitude = new p5.Amplitude();
  reverb = new p5.Reverb();

  // Just create the GUI object — it manages itself
  gui = createGui();

  // These automatically appear in the GUI
  volumeSlider = createSlider("Volume", 0, 1, 0.5, 100, 100, 200, 20);
  speedSlider = createSlider("Speed", 0.5, 2.0, 1.0, 100, 140, 200, 20);
  reverbToggle = createToggle("Reverb", false, 100, 180, 200, 20);
  switchButton = createButton("Switch Track", 100, 220, 200, 30);

  switchToTrack(trackA);
}
}

function draw() {
  background(30);
  drawDJBoard();

  if (currentTrack) {
    currentTrack.setVolume(volumeSlider.val);
    currentTrack.rate(speedSlider.val);

    if (reverbToggle.val !== lastReverbState) {
      currentTrack.disconnect();
      if (reverbToggle.val) {
        currentTrack.connect(reverb);
        reverb.process(currentTrack, 3, 2);
      } else {
        currentTrack.connect();
      }
      lastReverbState = reverbToggle.val;
    }
  }

  if (switchButton.val && !lastSwitchButtonState) {
    if (currentTrack === trackA) {
      switchToTrack(trackB);
    } else if (currentTrack === trackB) {
      switchToTrack(trackC);
    } else {
      switchToTrack(trackA);
    }
  }
  lastSwitchButtonState = switchButton.val;

  if (currentTrack && currentTrack.isPlaying()) {
    let level = amplitude.getLevel();
    let visSize = map(level, 0, 0.3, 20, 150);
    fill(100, 200, 255);
    ellipse(width * 0.5, height * 0.75, visSize, visSize);
  } else {
    fill(80);
    ellipse(width * 0.5, height * 0.75, 50, 50);
  }
}

function switchToTrack(track) {
  if (currentTrack && currentTrack.isPlaying()) {
    currentTrack.stop();
  }

  currentTrack = track;
  amplitude.setInput(currentTrack);
  currentTrack.disconnect();

  if (reverbToggle.val) {
    currentTrack.connect(reverb);
    reverb.process(currentTrack, 3, 2);
  } else {
    currentTrack.connect();
  }

  currentTrack.setVolume(volumeSlider.val);
  currentTrack.rate(speedSlider.val);
  currentTrack.loop();
}

function drawDJBoard() {
  fill(60);
  rect(width * 0.05, height * 0.05, width * 0.9, height * 0.9, 20);
  fill(80);
  rect(width * 0.1, height * 0.1, width * 0.35, height * 0.4, 15);
  rect(width * 0.55, height * 0.1, width * 0.35, height * 0.4, 15);

  fill(200);
  textSize(20);
  textAlign(CENTER, CENTER);
  text("Track Controls", width * 0.325, height * 0.1 + 20);
  text("Effects", width * 0.725, height * 0.1 + 20);

  stroke(80);
  strokeWeight(2);
  fill(40);
  ellipse(width * 0.5, height * 0.75, 200, 200);
  noStroke();
  fill(120);
  textSize(16);
  text("Visualizer", width * 0.5, height * 0.75 - 60);
}

function windowResized() {
  resizeCanvas(windowWidth, windowHeight);
}
