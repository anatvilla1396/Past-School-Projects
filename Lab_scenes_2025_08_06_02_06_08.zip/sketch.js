var jewel;
var comingSoon;

function preload(){
  jewel = loadImage('Screenshot 2024-09-23 122625.png')
  comingSoon = loadImage ('Screenshot 2025-01-17 172219.png')
}

//scene variable
var scene = 1;

function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  if (mouseIsPressed == true){
    image(jewel,200,200)
  }
  
  if (scene == 1){
    text("Nope!",200,200)
    image(comingSoon,200,200,200,200)   
  }
  
  if (scene == 2){
    text("Yup!",100,100)
    image(jewel,0,0,200,200)
  }  
    
  if (keyCode == UP_ARROW){
    scene = 2;
  }
    
  if (keyCode == DOWN_ARROW){
    scene = 1;  
  }
    /// image here
s
}

