//https://github.com/bmoren/p5.geolocation/blob/master/p5.geolocation.js


var locationData;
var currentLatitude;
var currentLongitude;
var currentAccuracy;
var currentAltitude;
var currentAltitudeAccuracy;
var currentHeading;
var currentSpeed;

function doThisOnLocation(position){
  currentLatitude = position.latitude;
  currentLongitude = position.longitude;
  currentAccuracy = position.accuracy;
  currentAltitude = position.altitude;
  currentAltitudeAccuracy = position.altitudeAccuracy;
  currentHeading = position.heading;
  currentSpeed = position.speed;
  print("lat: " + position.latitude);
  print("long: " + position.longitude);
}

function positionChanged(position){
  print("lat: " + position.latitude);
  print("long: " + position.longitude);
  currentLatitude = position.latitude;
  currentLongitude = position.longitude;
  currentAccuracy = position.accuracy;
  currentAltitude = position.altitude;
  currentAltitudeAccuracy = position.altitudeAccuracy;
  currentHeading = position.heading;
  currentSpeed = position.speed;
  print("lat: " + position.latitude);
  print("long: " + position.longitude);
}

function setup() {
  createCanvas(400, 400);
  if (geoCheck() == true) {
    //geolocation is available
    print("Geolocation is available");
  } else {
    //error getting geolocation
    print("Geolocation is not available");
  }
  getCurrentPosition(doThisOnLocation);
  watchPosition(positionChanged);
}    

function draw() {
  background(220);
}