let song1, song2;
let currentSong1, currentSong2; 
let isPlaying1 = false;
let isPlaying2 = false;
let gui;
let speedSlider1, speedSlider2;
let ampSlider1, ampSlider2;
let loadButton1, loadButton2;
let playPauseButton1, playPauseButton2;
let songPositionSlider1, songPositionSlider2; // sliders for track 
let amp1, amp2; 
let vl1 = 0,vl2 = 0;
let circleRadius1, circleRadius2;
let x1, y1, x2, y2;
let sync1Toggle, sync2Toggle; //  toggle variables
let sync1State = false;
let sync2State = false;
let djBoard; 
let djhands;
let saturn;
let retrograde, retrotv, stars;
let opacitySlider; 

function preload() {
  song1 = loadSound('Another life (feat. Rema).mp3');
  song2 = loadSound('Tame Impala The Less I Know The Better (Isolated Vocal Track) (1).mp3');
  song3 = loadSound("Riton, Kah-Lo & GEE LEE - Fake ID (Coke & Rum Remix).mp3")
  djBoard = loadImage('dj board.png'); 
  djhands = loadImage("dj hands.png");
  saturn = loadImage("saturn.png");
  retrograde = loadImage("rings.png");
  retrotv = loadImage("retro tv.png");
  stars = loadImage("stars.png");
}

function setup() {
  createCanvas(400, 400);
  gui = createGui();

  // speed and amp sliders
  speedSlider1 = createSlider("Speed 1", 50, 50, 150, 20, 0.5, 2, 1, 0.01);
  speedSlider2 = createSlider("Speed 2", 50, 80, 150, 20, 0.5, 2, 1, 0.01);
  ampSlider1 = createSlider("Opacity", 50, 110, 150, 20, 0, 1, 1, 0.01); 
  ampSlider2 = createSlider("X Position", 50, 140, 150, 20, 0, width, width / 2, 1);  

  //  song position sliders
  songPositionSlider1 = createSlider("Position 1", 50, 170, 300, 20, 0, 100, 0, 0.1);
  songPositionSlider1.onInput = handleSongPositionSlider1Input;
  songPositionSlider2 = createSlider("Position 2", 50, 200, 300, 20, 0, 100, 0, 0.1);
  songPositionSlider2.onInput = handleSongPositionSlider2Input;

  loadButton1 = createButton("Load Track 1", 250, 50);
  loadButton1.onPress = loadAndPlayTrack1;
  loadButton2 = createButton("Load Track 2", 250, 80);
  loadButton2.onPress = loadAndPlayTrack2;

  // play/Pause 
  playPauseButton1 = createButton("Play 1", 250, 110);
  playPauseButton1.onPress = togglePlayPause1;
  playPauseButton2 = createButton("Play 2", 250, 140);
  playPauseButton2.onPress = togglePlayPause2;

  //  sync toggles (used ai for help)
  sync1Toggle = createToggle("Sync 1", 50, 230, 80, 20); // Adjusted Y position
  sync1Toggle.onToggle = function () {
    sync1State = this.state;
  };
  sync2Toggle = createToggle("Sync 2", 150, 230, 80, 20); // Adjusted Y position
  sync2Toggle.onToggle = function () {
    sync2State = this.state;
  };

  x1 = ampSlider2.val; 
  x2 = ampSlider2.val;
  amp1 = new p5.Amplitude();
  amp2 = new p5.Amplitude();
  
  circleRadius1 = 10;
  circleRadius2 = 10;
  noStroke();
  y1 = 300; 
  y2 = 300; 
  colorMode(HSB, 360, 100, 100, 1); //  HSB color mode - hue sat brit
}

function draw() {
  background(stars);
  image(retrotv, 10, 250, 400, 150);

  let combinedAmplitude = (amp1.getLevel() + amp2.getLevel()) / 2;
  let opacityValue = ampSlider1.val; // ampSlider1 for opacity

  image(djBoard, 0, -50, 400, 400); 

  x1 = ampSlider2.val; // ampSlider2 for x position
  x2 = ampSlider2.val;

  // song 1 updates
  if (currentSong1 && currentSong1.isPlaying()) {
    currentSong1.rate(speedSlider1.val);
    currentSong1.amp(ampSlider1.val); //ampSlider1 was here and caused issues
    songPositionSlider1.val = (currentSong1.currentTime() / currentSong1.duration()) * 100;
    vl1 = amp1.getLevel();
    let handSize1 = map(vl1, 0, 1, 50, 200); // Map amplitude to size
    if (typeof handSize1 === 'number') { // Check if handSize1 is a valid number
      push(); // Save current drawing style
      tint(255, opacityValue); // Apply opacity
      image(saturn, x1, y1, handSize1, handSize1);
      pop(); // Restore previous drawing style
    } else {
      push();
      tint(255, opacityValue);
      image(saturn, x1, y1, 50, 50); // Use a default size if not a number
      pop();
    }
  } else {
    push();
    tint(255, opacityValue);
    image(saturn, x1, y1, 50, 50); // show small image when not playing
    pop();
  }

  // Update and draw for song 2
  if (currentSong2 && currentSong2.isPlaying()) {
    currentSong2.rate(speedSlider2.val);
    currentSong2.amp(ampSlider1.val);
    songPositionSlider2.val = (currentSong2.currentTime() / currentSong2.duration()) * 100;
    vl2 = amp2.getLevel();
    let handSize2 = map(vl2, 0, 1, 50, 200); // Map amplitude to size
    if (typeof handSize2 === 'number') {  // Check if handSize2 is a valid number
      push();
      tint(255, opacityValue); // Apply opacity
      image(retrograde, x2, y2, handSize2, handSize2);
      pop();
    } else {
      push();
      tint(255, opacityValue);
      image(retrograde, x2, y2, 50, 50); // Use default size
      pop();
    }
  } else {
    push();
    tint(255, opacityValue);
    image(retrograde, x2, y2, 50, 50);
    pop();
  }

  drawGui();
  image(djhands, mouseX - 50, mouseY - 50, 200, 200);
}

function loadAndPlayTrack1() {
  stopCurrentSong(1); // Stop any previous playing on track 1
  currentSong1 = song1;
  startCurrentSong(1);
}

function loadAndPlayTrack2() {
  stopCurrentSong(2);
  currentSong2 = song2;
  startCurrentSong(2);
}

function startCurrentSong(trackNumber) {
  let songToPlay = trackNumber === 1 ? song1 : song2;
  if (songToPlay) {
    songToPlay.loop();
    songToPlay.playMode('restart');
    if (trackNumber === 1) {
      isPlaying1 = true;
      playPauseButton1.label = "Pause 1";
      songPositionSlider1.range(0, song1.duration());
    } else {
      isPlaying2 = true;
      playPauseButton2.label = "Pause 2";
      songPositionSlider2.range(0, song2.duration());
    }
  }
}

function stopCurrentSong(trackNumber) {
  if (trackNumber === 1) {
    if (currentSong1 && currentSong1.isPlaying()) {
      currentSong1.stop();
      isPlaying1 = false;
      playPauseButton1.label = "Play 1";
    }
  } else {
    if (currentSong2 && currentSong2.isPlaying()) {
      currentSong2.stop();
      isPlaying2 = false;
      playPauseButton2.label = "Play 2";
    }
  }
}

function pauseCurrentSong(trackNumber) {
  if (trackNumber === 1) {
    if (currentSong1 && currentSong1.isPlaying()) {
      currentSong1.pause();
      isPlaying1 = false;
      playPauseButton1.label = "Play 1";
    }
  } else {
    if (currentSong2 && currentSong2.isPlaying()) {
      currentSong2.pause();
      isPlaying2 = false;
      playPauseButton2.label = "Play 2";
    }
  }
}

function playCurrentSong(trackNumber) {
  let songToPlay = trackNumber === 1 ? song1 : song2;
  if (songToPlay) {
    songToPlay.loop();
    songToPlay.playMode('restart');
    if (trackNumber === 1) {
      isPlaying1 = true;
      playPauseButton1.label = "Pause 1";
      songPositionSlider1.range(0, song1.duration());
    } else {
      isPlaying2 = true;
      playPauseButton2.label = "Pause 2";
      songPositionSlider2.range(0, song2.duration());
    }
  }
}

function handleSongPositionSlider1Input() {
  if (currentSong1) {
    song1.currentTime(songPositionSlider1.val / 100 * song1.duration());
  }
}

function handleSongPositionSlider2Input() {
  if (currentSong2) {
    song2.currentTime(songPositionSlider2.val / 100 * song2.duration());
  }
}

function togglePlayPause1() {
  if (isPlaying1) {
    song1.pause();
    isPlaying1 = false;
    playPauseButton1.label = "Play 1";
    print("Off 1");
  } else {
    playCurrentSong(1);
  }
}

function togglePlayPause2() {
  if (isPlaying2) {
    song2.pause();
    isPlaying2 = false;
    playPauseButton2.label = "Play 2";
    print("Off 2");
  } else {
    playCurrentSong(2);
  }
}
