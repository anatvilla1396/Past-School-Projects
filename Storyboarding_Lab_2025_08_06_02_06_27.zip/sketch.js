var scene=1

function preload(){
  board1 = loadImage("0-1.jpg")
  board2 = loadImage("0-2.jpg")
  board3 = loadImage("0-3.jpg")
  board4 = loadImage("0-4.jpg")
  board5 = loadImage("0.jpg")
  sound = loadSound('Future mask off Sport cars_30 sec. Videos for WhatsApp_car lovers.mp3')
  sound= loadSound("776646__artninja__blade_slice_metal_01.mp3")}
    
function setup() {
  createCanvas(400, 400);
}

function draw(){
  background("#043b59")
  
  if (scene==1){
    fill(255)
    image(board1,0,0,400,400)
    textSize(25)
    textWrap(WORD)
    text("I Got Hands",50,50)
    textSize(15)
    text("a comic by Ana Villavasso",40,90)
    textSize(12)
    text("The weather is so nice out tonight. It doesn't even seem like February.",25,350,350)}
  
  if (scene==2){
    image(board2,0,0,400,400)
    fill(0)
    textSize(12)
    textWrap(WORD)
    text("Yeah, but with the full moon out and all that hair you have, I hope you don't turn into a werewolf!",25,340,350)}

  if (scene==3){
    sound && !sound.isPlaying(); {
    sound.play();}
    image(board3,0,0,400,400)}

  if (scene==4){
    image(board4,0,0,400,400)
    fill(255)
    textSize(20)
    textWrap(WORD)
    text("What the-!",190,340,350)}
  
  if (scene==5){
    image(board5,0,0,400,400)
    fill(255)
    textSize(12)
    textWrap(WORD)
    text("Never comment on a woman's body.",100,340,350)
    fill("#f5c842")
    text("Good god! You didn't have to SLICE me!",250,50,150)}
}

function mousePressed(){
  scene++;
  if (scene > 5){
    scene=1}
  print(scene)
}