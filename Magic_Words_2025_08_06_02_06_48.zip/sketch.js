let dadjokes = 'Try interacting with your computer. You can double click, press a key, press the mouse, drag the mouse, or scroll.'
let bgColor = 255

function setup() {
  createCanvas(400,400);
  textSize(20);
  textWrap(WORD);
  textAlign(CENTER);
  noLoop();
}

function draw() {
  background(bgColor);
  text(dadjokes,25,150,350)
}
function doubleClicked(){  
  bgColor="#eb4034";
  square(0,0,400);
  fill(255);
  dadjokes = 'Why did the scarecrow win an award? Because he was outstanding in his field!';
  redraw();}

function keyPressed() {
  bgColor="#ebb434";
  square(0,0,400);
  fill(0);
  dadjokes = 'What do you call a fish wearing a bowtie? Sofishticated.'
  redraw();
}
function keyReleased (){
  bgColor="#ffee05";
  square(0,0,400);
  fill(0);
  dadjokes = 'Why don’t skeletons fight each other? They don’t have the guts.'
   redraw();
}
function mouseClicked (){
  bgColor="#68963f";
  square(0,0,400);
  fill(255);
  dadjokes = 'I told my wife she should embrace her mistakes. She gave me a hug.'
   redraw();
}
function mouseDragged (){
  bgColor="#2659c7";
  square(0,0,400);
  fill(255);
  dadjokes = 'Why can’t you give Elsa a balloon? Because she will let it go!'
   redraw();
}
function mouseWheel(){
  bgColor="#c995e8";
  square(0,0,400);
  fill(0);
  dadjokes = 'I only know 25 letters of the alphabet. I don’t know Y.'
  redraw();
}



