let snake;
let foodItems = []; //class
let gridSize = 20;
let cols, rows;
let score = 0;
let timer = 60;
let gameState = "start";
let snakeImg, appleImg, backgroundImg;

function preload() {
  snakeImg = loadImage("snake icon.png");
  appleImg = loadImage("apple icon.png");
  backgroundImg = loadImage("world.png");
}

function setup() {
  createCanvas(400, 400);
  frameRate(10);
  cols = width / gridSize;
  rows = height / gridSize;
  snake = new Snake();
  for (let i = 0; i < 8; i++) {
    foodItems.push(new Food());}
  noTint(); 
}

function draw() {
  if (gameState === "start") {
    showStart();
  } else if (gameState === "playing") {
    noTint(); 
    image(backgroundImg, 0, 0, width, height);
    snake.update();
    snake.show();

    for (let i = 0; i < foodItems.length; i++) {
      foodItems[i].show(); 
      if (snake.eats(foodItems[i])) {
        score++;
        foodItems[i].reset();}
    }

    showScore();
    
    showTimer();
    timer -= 1 / frameRate();

    if (timer <= 0) {
      gameState = score >= 30 ? "win" : "lose";
    }
  } else if (gameState === "win") {
    showEnd("YOU WIN!");
  } else if (gameState === "lose") {
    showEnd("GAME OVER");
  }
}

function keyPressed() {
  if (gameState === "start" && keyCode === ENTER) {
    gameState = "playing";
    noTint(); 
  }
  if ((gameState === "win" || gameState === "lose") && key === "r") {
    resetGame();
  }

  if (key === "w") snake.setDir(0, -1); //calls from CLASS
  if (key === "s") snake.setDir(0, 1);
  if (key === "a") snake.setDir(-1, 0);
  if (key === "d") snake.setDir(1, 0);
}

class Snake { //
  constructor() {
    this.x = 100; // start position in pixels
    this.y = 100;
    this.xdir = 1;
    this.ydir = 0;}

  setDir(x, y) {
    this.xdir = x;
    this.ydir = y;}

  update() {
    this.x += this.xdir * gridSize;
    this.y += this.ydir * gridSize;}

  show() {
    image(snakeImg, this.x, this.y, gridSize, gridSize);}

  eats(food) {
    return this.x === food.x && this.y === food.y;}
}


class Food {
  constructor() {
    this.reset(); //reset method
  }

  reset() {
    this.x = floor(random(cols)) * gridSize;
    this.y = floor(random(rows)) * gridSize;
  }

  show() {
    image(appleImg, this.x, this.y, gridSize, gridSize);
  }
}


function showScore() {
  fill(255);
  textSize(14);
  text("Score: " + score, 10, 20);}

function showTimer() {
  fill(255);
  textSize(14);
  text("Time: " + timer.toFixed(0), 330, 20);}

function showStart() {
  background(50);
  image(backgroundImg, 0, 0, 400, 400);
  tint(255, 150);
  fill(255);
  textAlign(CENTER);
  textSize(24);
  text("SNAKEY CHOMP CHOMP", width / 2, height / 2 - 20);
  textSize(16);
  text("Press ENTER to begin chomping. Get 30 to win!", width / 2, height / 2 + 20);}

function showEnd(msg) { //msg allows for multiple scenes 
  background(0);
  fill(255);
  textAlign(CENTER);
  textSize(32);
  text(msg, width / 2, height / 2);
  textSize(16);
  text("Press R to Restart", width / 2, height / 2 + 40);
}

function resetGame() { //copied from above
  score = 0;
  timer = 60;
  snake = new Snake();
  foodItems = [];
  for (let i = 0; i < 8; i++) {
    foodItems.push(new Food());} //adds to body (push)
  gameState = "start";
}
