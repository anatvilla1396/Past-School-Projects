//if this doesnt work load 

//speech.js
let speech;
let speechRec;

//life imitates art
let x;
let v;
let t;
let dt;

let scene = 1; 

//joystick
let gui;
let j; //joystick
let xx, y, velX, velY;
let trail = [];

//slider
let s;
let randomColor;

function setup() {
  createCanvas(400, 400);
  gui = createGui();
  j = createJoystick("Joystick", 10, 210, 175, 175, -1, 1, 1, -1);
  x = 300;
  y = 100;
  velX = 0;
  velY = 0;
  s = createSlider("Slider", 15, 120, 175, 25, 0, 200); // min to 50
  xx = 0;
  v = 0;
  t = 0;
  dt = 1;
  n = -1;
  textFont('Comic Sans MS');
  randomColor = color(random(255), random(255), random(255)); // randomColor
  speech = new p5.Speech();
  speech.setRate(1.2); // fast speech
  speech.setPitch(10)
  speechRec = new p5.SpeechRec('en-US', gotSpeech);
  speechRec.start()
  
}

function preload() {
  welcome = loadImage("Screenshot 2025-04-12 190106.jpg");
  appscalc = loadImage("apps of calc.png");
  integrals = loadImage("integrals.png");
  revolutions1 = loadImage("volumes of revolution.png");
  revolutions2 = loadImage("revolutions.png");
  surfaceintegrals = loadImage("surface integrals.png");
  polarcoords = loadImage("polar coords.png");
}

//custom function
function calculusCurve() {
  let x1 = 50;
  let y1 = 350;
  let cx1 = 50;
  let cy1 = 100;
  let cx2 = 150;
  let cy2 = 350;
  let x2 = 200;
  let y2 = 200;

  noFill();
  stroke(0);
  bezier(x1, y1, cx1, cy1, cx2, cy2, x2, y2);

  stroke(150);
  line(x1, y1, cx1, cy1);
  line(x2, y2, cx2, cy2);
  fill(255, 0, 0);
  ellipse(x1, y1, 5, 5);
  ellipse(x2, y2, 5, 5);
  fill(0, 0, 255);
  ellipse(cx2, cy2, 5, 5);

  stroke(0);
  line(50, 0, 50, 400);
  line(0, 350, 400, 350);
}
function gotSpeech() {
  if (speechRec.resultValue) {
    let said = speechRec.resultString.toLowerCase();
    console.log(said);

    if (said.includes('next')) {
      simulateKeyPress(); // Call a function to simulate key press
      speech.speak('Simulating key press.');
    }
  }
}
function simulateKeyPress() {
  // Simulate the keyPressed() function being called.
  keyPressed();}

function keyPressed() {
  if (keyCode == RIGHT_ARROW) {
    scene++;
    if (scene > 12) {
      scene = 1;
    }
  } else if (keyCode == LEFT_ARROW) {
    scene--;
    if (scene < 1) {
      scene = 12;
    }
  }
}

function mousePressed() {
  n = n + 1;
  t = t + dt;
  v = t * t;
  xx = xx + v * dt;
  randomColor = color(random(255), random(255), random(255)); // Change color on mouse press
}

//draw
function draw() {
  background(255);
  let gridSize = 40; 
  let numCellsX = width / gridSize;
  let numCellsY = height / gridSize;
  stroke(200); 

  // vertical lines
  for (let i = 0; i <= numCellsX; i++) {
    let x = i * gridSize;
    line(x, 0, x, height);
  }

  // horizontal lines
  for (let j = 0; j <= numCellsY; j++) {
    let y = j * gridSize;
    line(0, y, width, y);
  }
  
  
  print(mouseX, mouseY);
  textWrap(WORD);
  textAlign(CENTER, CENTER);

  //welcome
  if (scene == 1) {
    textSize(20);
    text("Calculus for Dummies", 200, 100);
    text("Calculus I, II, and III explained like a fifth grader!", 50, 300, 300);
    image(welcome, 150, 150, 100, 100);
  }

  //slide 1
  if (scene == 2) {
    textSize(15);
    speech.speak("Welcome to calc for dummies. This is not as scary as it looks. Calculus can actually be kind of fun! Calculus is the study of movement through three dimensional space.")
    text("Welcome to calc for dummies. This is not as scary as it looks. Calculus can actually be kind of fun!", 60, 50, 300);
    textSize(20);
    text("Calculus is the study of movement through three dimensional space.", 220, 250, 150);
    calculusCurve();
    if (keyIsPressed && key == 'c') {
      line(190, 262, 229, 155);
      let angle = atan2(155 - 262, 229 - 190);
      translate(229, 155);
      rotate(angle);
      triangle(-10, -5, 0, 0, -10, 5);
      resetMatrix();
    }
  }

  //slide 2
  if (scene == 3) {
    fill(0);
    textSize(18)
    speech.speak("Calculus usually starts with functions. Functions give you formulas to measure where points on a line will end up. There are infinitely many points in a function, they can be traced by a curve on the xy-plane.Use the joystick to trace the curve. Each circle represents an x and y value, input and output. ")
    text("Calculus usually starts with functions. Functions give you formulas to measure where points on a line will end up.", 50, 50, 300);
    textSize(9)
    text("There are infintely many points in a function, they can be traced by a curve on the xy-plane (vertical and horizontal)", 300, 140, 100);
    text("Use the joystick to trace the curve. Each circle represents an x and y value, input and output.", 250, 300, 100);

    //joystick: source github and gemini.google.com
    drawGui();
    s.visible = false;
    velX += j.valX * 0.1; // "reduced multipllier" smoother control
    velY += j.valY * 0.1;
    //friction
    velX *= 0.98;
    velY *= 0.98;
    // update position based on velocity
    x += velX;
    y += velY;
    // addurrent position to the trail
    trail.push({ x: x, y: y });
    // limit trail length to prevent from growing indefinitely
    if (trail.length > 50) {
      trail.shift();
    }
    // draw
    fill("#7AA0FF"); // Use the same fill color as the ellipse
    noStroke();
    for (let i = 0; i < trail.length; i++) {
      let size = map(i, 0, trail.length - 1, 2, 10); // Adjust size for fading effect
      ellipse(trail[i].x, trail[i].y, size);
    }
    noFill();
    stroke(0);
    bezier(50, 150, 150, 10, 164, 255, 287, 100);
    line(35, 80, 35, 180);
    line(35, 180, 350, 180);
  }

  //slide 3
  if (scene == 4) {
    textSize(20);
    fill(0);
    stroke(0)
    speech.speak("You can calculate the slope, which is the steepness of the curve by taking the derivative. Sometimes the derivative is another curve. That's ok! You could even keep taking more derivatives. This is where Calculus 2 gets complicated, as these derivatives can be logarithms, exponents, and even not exist! ")
    text("You can calculate the slope, which is the steepness of the curve by taking the derivative.", 20, 50, 350);
    text("Sometimes the derivative is another curve. That's ok! You could even keep taking more derivatives.", 20, 350, 350);

    noFill();
    bezier(40, 300, 100, 100, 240, 300, 350, 100);

    //slider: source github
    drawGui();
    j.visible = false;
    s.visible = true; // Slider is visible here

    strokeWeight(1);

    // line slider
    let lineLength = s.val;
    let midX = 109;
    let midY = 206;
    let startX = midX - lineLength / 2;
    let startY = midY + lineLength / 2;
    let endX = midX + lineLength / 2;
    let endY = midY - lineLength / 2;

    push();
    rotate(radians(5));
    line(startX, startY, endX, endY);
    pop();

    // line slider 2
    let lineLength2 = s.val;
    let midX2 = 320; // Corrected midX2
    let midY2 = 100;
    let startX2 = midX2 - lineLength2 / 2; // Corrected midX2
    let startY2 = midY2 + lineLength2 / 2; // Corrected midX2
    let endX2 = midX2 + lineLength2 / 2; // Corrected midX2
    let endY2 = midY2 - lineLength2 / 2; // Corrected midX2

    push();
    rotate(radians(15));
    line(startX2, startY2, endX2, endY2);
    pop();
  }

  //slide 4
  if (scene == 5) {
    s.visible = false
    j.visible = false
    textSize(20);
    fill(0,255,0)
    speech.speak("This is boring and complicated. Why should I care?   Derivatives and integrals can tell you lots. In physics it represents velocity, speed, and acceleration. It is used in engineering to optimize designs and for structural integrity. Or, what if you are building something on a steep hill? You need to know that the building won't fall, or how strong the structures that are holding the building up need to be. Think about this in artistic contexts as well!")
    text("This is boring and complicated. Why should I care...", 100, 50, 200);
    textSize(15);
    text("Derivatives and integrals can tell you lots. In physics it represents velocity, speed, and acceleration. It is used in engineering to optimize designs and for structural integrity. Or, what if you are building something on a steep hill?", 10, 350, 375);
    image(appscalc, 50, 100, 300, 175);
    drawGui();
  }

  //slide five
  if (scene == 6) {
    s.visible = false
    j.visible = false
    textSize(15);
    fill(0);
    speech.speak("Calculus can also teach you a lot about data. If points on a line are curves, then you can calculate the highest and lowest point, the place it increases or decreases the most, changes in value and more! This is especially important for data scientists and general sciences as well.")
    text("Calculus can also teach you a lot about data. If points on a line are curves, then you can calculate the highest and lowest point, the place it increases or decreses the most, changes in value and more!", 25, 50, 350);
    text("Red = Changes in transition in data", 220, 325);
    text("Blue = Change in concavity and convexity of curve", 230, 345);
    text("Green = Highest and lowest points", 220, 365);
    noFill();
    stroke(0);
    bezier(50, 350, 100, 50, 300, 350, 350, 100);

    // critical points
    fill(255, 0, 0);
    noStroke();
    ellipse(124, 211, 8, 8);
    ellipse(303, 193, 8, 8);

    // inflection point
    fill(0, 0, 255);
    ellipse(225, 208, 8, 8);

    // min/max points
    fill(0, 255, 0);
    ellipse(50, 350, 8, 8); // min Y
    ellipse(350, 100, 8, 8); // min X
    drawGui();
  }

  //slide 6
  if (scene == 7) {
    s.visible = false
    j.visible = false
    textSize(20);
    speech.speak("Integrals are the opposite of derivatives. They are gross to calculate. This is where we move to two-dimensional shapes instead of just curves. Integrals calculate the area under a curve, or the total space underneath a shape made from a curve.")
    text("Integrals are the opposite of derivatives. This is where we move to two-dimensional shapes instead of just curves. Integrals calculate the area under a curve, or the total space underneath a shape made from a curve.", 50, 100, 300);
    image(integrals, 120, 200, 175, 175);
    drawGui();
  }

  //slide 7
  if (scene == 8) {
    s.visible = false
    j.visible = false
    textSize(18);
    speech.speak("My favorite lesson in Calc 2 was learning about volumes and areas of revolution. This is what made me a math minor with my art major! This is the idea that you can calculate the volume and area of revolution of a two dimensional shape if it is rotated around some invisible axis. In other words, you can calculate the volume of a three dimensional shape just by having the function of the shape that it makes up!")
    text("My favorite lesson in Calc 2 was learning about volumes of revolution. This is what made me a math minor!", 15, 50, 300);
    textSize(10);
    text("This is the idea that you can calculate the volume and area of revolution of a two dimensional shape if it is rotated around some invisible axis.", 15, 350, 200);
    text("In other words, you can calculate the volume of a three dimensional shape just by having the function of the shape that it makes up!", 215, 350, 200);
    image(revolutions1, 25, 115, 150, 150);
    image(revolutions2, 225, 115, 150, 150);
    drawGui();
  }

  //slide 8
  if (scene == 9) {
    s.visible = false
    j.visible = false
    textSize(15);
    speech.speak("This leads to Calculus 3, which explores how to calculate specific attributes of three-dimensional objects. Yes, there is a Calculus 3. It is quite literally only math majors. This class also teaches us how to calculate the volume of complicated two dimensional surfaces like this one, called surface integrals. There is also calculating three dimensional cones, bowls, and even pringles!")
    text("This leads to Calculus 3, which explores how to calculate specific attributes of three-dimensional objects.", 15, 50, 300);
    text("It also teaches us how to calculate the volume of complicated two dimensional surfaces like this one, called surface integrals.", 105, 350, 300);
    image(surfaceintegrals, 80, 100, 200, 200);
    drawGui();
  }

  //slide 9
  if (scene == 10) {
    s.visible = false
    j.visible = false
    speech.speak("We can also calculate attributes of not physical objects, such as water flow and even the direction in which the wind flows!But mostly, we focus on 2D objects, specifically lots of spheres and circles. Sometimes we have to even change the graph to calculate these attributes. Annoying!")
    text("We can also calculate attributes of not physical objects, such as water flow and even the direction in which the wind flows!", 15, 50, 300);
    text("But mostly, we focus on 2D objects, specifically lots of spheres and circles. Sometimes we have to even change the graph to calculate these attributes. Annoying!", 15, 140, 300);
    image(polarcoords, 20, 170, 350, 200);
    drawGui();
  }

  //slide 10
  if (scene == 11) {
    s.visible = false
    j.visible = false
    textSize(20);
    fill("#8fe1f7");
    // cloud
    noStroke();
    ellipse(130, 170, 60, 60);
    ellipse(150, 120, 100, 70);
    ellipse(200, 170, 90, 65);
    ellipse(230, 125, 80, 55);
    ellipse(270, 165, 70, 50);
    ellipse(80, 180, 40, 30);
    ellipse(60, 200, 30, 20);
    ellipse(45, 215, 20, 15);
    fill(0);
    speech.speak("Many people ask why I am a math minor and an art major. It is not easy. I am exercising both the creative and analytical parts of my brain simultaneously, all of the time. But it means that I have a very unique approach to both research and creative projects. I have always loved shapes, geometry and three dimensional space. I loved sketching and painting, but I was also pretty good at math.My minor teaches me how to inform my designs with an engineering and mathematical perspective, allowing me to be both an industrial designer and engineer.My major teaches me how to support my Calc findings with detailed visualizations, furthering my own understanding of both.")
    text("Why are you an art major and a math minor?", 45, 50, 300);
    textSize(12);
    text("I have always loved shapes, geometry and three dimensional space. I loved sketching and painting, but I was also pretty good at math.", 50, 280, 300);
    text("My minor teaches me how to inform my designs with an engineering and mathematical perspective, allowing me to be both an industrial designer and engineer.", 10, 350, 200);
    text("My major teaches me how to support my Calc findings with detailed visualizations, furthering my own understanding of both.", 240, 350, 150);
    drawGui();
  }

  //slide 11
  if (scene == 12) {
    s.visible = false
    j.visible = false
//mysteries of calc: source https://editor.p5js.org/claesjohnson/sketches/B1lmBoVaQ
    textSize(20);
    stroke(0);
    line(10, 0, 10, 400);
    line(0, 300, 400, 300);
    text("Life imitates art, including math!", 50, 50, 300);
    text("Thank you for listening!", 50, 370, 300);

    strokeWeight(1);
    noStroke();
    fill(randomColor);
    rect(n * dt * 20, 300 - v, 20 * dt, v);
    fill(255, 0, 0, 255);
    fill(randomColor);
    rect(n * dt * 20, 300 - v - 3, 20 * dt, 4);
   
  }
}

