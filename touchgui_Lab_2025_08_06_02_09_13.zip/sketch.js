let gui;
//button
let b;
//slider
let s;
//joystick
let j;
let x, y, velX, velY;

function setup() {
  createCanvas(400, 400);
  gui = createGui();
  
  b = createButton("Button", 250, 250);
  s = createSlider("Slider", 50, 50, 300, 32, 100, 300);
  j = createJoystick("Joystick", 10, 210, 175, 175, -1, 1, 1, -1);
  
  // Starting position and velocity
  x     = 300;
  y     = 100;
  velX  = 0;
  velY  = 0;
  
}

function draw() {
  background(220);
  drawGui();

  if(b.isPressed) {
    print(b.label + " is pressed.");
  }
  
  if (s.isChanged) {
    // Print a message when Slider is changed
    // that displays its value.
    print(s.label + " = " + s.val);
  }
  
  // Use Slider's value to determine where the ellipse is drawn.
  fill(255, 0, 0);
  ellipse(s.val, 300, 100);
  
  if (j.isChanged) {
    // Print a message when Slider 1 is changed
    // that displays its value.
    print(j.label + " = {" + j.valX + ", " + j.valY + "}");
  }
  
  // Use Joystick's output to change velocity
  velX += j.valX;
  velY += j.valY;  
  
  // Draw our ellipse
  fill("#7AA0FF");
  stroke("#FFFFFF")
  ellipse(x + velX, y + velY, 100);
}

function touchMoved() {
  // do some stuff
  return false;
}