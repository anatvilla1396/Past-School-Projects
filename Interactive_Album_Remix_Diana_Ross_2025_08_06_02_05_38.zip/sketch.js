let fadeAmount=0;
let fadeDirection = 1;

function setup() {
  createCanvas(500, 500);
}

function preload() {
  sound = loadSound('Diana RossHip Hop Type Beats- Love Hangover.mp3')}

//fader, silhouette,other shapes, settings, animation, lyrics, 

function draw() {
  background(0);
  let r = lerp(255, 0, fadeAmount);
  let g = lerp(203, 0, fadeAmount);
  let b = lerp(46, 0, fadeAmount);
  fill(r, g, b)
   fadeAmount += 0.01 * fadeDirection;
  if (fadeAmount >= 1 || fadeAmount <= 0) 
    fadeDirection *= -1;
 
  noStroke()
  square(270,70,100,10)
  triangle(290,210,210,263,300,340)
  rect(290, 168,70,150)
  ellipse(280,160,30,20)
  triangle(275,112,256,125,270,131)
  ellipse(325,70,100,50)
  circle(385,121,100)
  circle(385,80,100)
  quad(244,283,95,500,144,500,358,316)
  ellipse(365,258,40,120)
  
  fill(122, 84, 26)
  rect(65,368,75,200)
  fill(255)
  circle(126,436,15)
  
  fill(0)
  ellipse(269,145,20,10)
  
  fill("#d1ab43")
  textSize(25)
  textFont('Calibri')
  text('LOVE HANGOVER',27,52)
  textSize(10)
  text('if there is a cure for this, i do not want it!',27,72)
  text('diana ross',85,128)
  text('press any button to play audio. click and hold to view lyrics',20,220)
  text ('press 1 to view rankings.', 20,250)
  stroke("#d1ab43")
  strokeWeight(2)
  line(60,108,150,108);
  
  //
  
  text("💛",mouseX,mouseY)
  if (mouseX >= 263 && mouseY >= 147)
    fill(170)
    quad(226,147,214,167,232,176,250,147)
    ellipse(225,167,20,20)
    text("💛",225,164)
    fill(0)
    ellipse(240,144,25,10)
  if (mouseX >= 263 && mouseY >= 147)
    text("💛",288,143)
  if (mouseX >= 263 && mouseY >= 147)
    text("💛", 317,161)
  if (mouseX >= 263 && mouseY >= 147)
    text("💛", 328,201)
  if (mouseX >= 263 && mouseY >= 147)
    text("💛", 295,303)
  if (mouseX >= 263 && mouseY >= 147)
    text("💛", 318,260)
  
  if (keyCode == UP_ARROW){
    text("If there's a cure for this, I don't want it! I don't want it.",200,400)
    text("If there's a cure for this, I don't want it! I don't want it.",200,420)
    text('I think about it all the time, Thinking only makes me smile And say, hey...',200,440)
    text("I don't wanna shake it!I love the love you're making...",200,460);}
  
  if (mouseIsPressed == true){
    fill(0)
    square(50,50,400)
    textSize(10)
    text("If there's a cure for this, I don't want it! I don't want it.",70,150)
    text("If there's a cure for this, I don't want it! I don't want it.",70,190)
    text('I think about it all the time, Thinking only makes me smile And say, hey...',70,230)
    text("I don't wanna shake it!I love the love you're making...",70,270);}
  
  if (key == '1'){
    text('This song is ranked  ' + int(random(1,10001)) + '  in the United States currently.',20,350)
    }
  
  print(mouseX,mouseY)
}

function keyPressed() {
  if (sound && !sound.isPlaying()) {
    sound.play();}}

